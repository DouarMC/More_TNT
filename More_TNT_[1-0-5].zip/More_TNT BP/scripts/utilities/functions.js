export class ALL_FUNCTIONS {
    /**
     * Décrémenter la durabilité de l'itemStack spécifié ou renvoie Undefined
     * @param itemStack
     * @param damageAmount
     * @returns
     */
    static decrementItemStackDurability(itemStack, damageAmount = 1) {
        const durabilityComponent = itemStack.getComponent("minecraft:durability");
        if (durabilityComponent.damage + damageAmount >= durabilityComponent.maxDurability) {
            return undefined;
        }
        else {
            durabilityComponent.damage += damageAmount;
            return itemStack;
        }
        ;
    }
    ;
    /**
     * Placer un bloc en fonction de la face du bloc intéragit
     * @param blockToPlace
     * @param blockInteracted
     * @param blockFaceInteracted
     * @returns
     */
    static placeBlockDependingFaceInteracted(blockToPlace, blockInteracted, blockFaceInteracted) {
        const dimmension = blockInteracted.dimension;
        let block = undefined;
        switch (blockFaceInteracted) {
            case "Down":
                block = blockInteracted.below();
                break;
            case "East":
                block = blockInteracted.east();
                break;
            case "North":
                block = blockInteracted.north();
                break;
            case "South":
                block = blockInteracted.south();
                break;
            case "Up":
                block = blockInteracted.above();
                break;
            case "West":
                block = blockInteracted.west();
                break;
        }
        ;
        const entitiesAtBlockLocation = dimmension.getEntities({ "location": block.location, "families": ["mob", "player"] });
        if (entitiesAtBlockLocation.length != 0)
            return;
        block.setType(blockToPlace);
    }
    ;
    /**
     * Teste si le bloc est alimenté par un signal de redstone
     * @param block
     * @returns
     */
    static isBlockAlimented(block) {
        const connectedBlocks = [block.above(), block.below(), block.east(), block.north(), block.south(), block.west()];
        for (const connectedBlock of connectedBlocks) {
            if (connectedBlock.getRedstonePower() !== undefined && connectedBlock.getRedstonePower() !== 0) {
                return true;
            }
            ;
        }
        ;
        return false;
    }
    ;
    /**
     * Prend une liste d'objets composé d'une valeur et d'un poids de chance, et envoie un element au hasard basé sur le poids de chance.
     * @param elements
     * @returns
     */
    static chooseRandomElementWithWeight(elements) {
        const totalWeight = elements.reduce((total, item) => total + item.weight, 0);
        let randomWeight = Math.random() * totalWeight;
        for (const element of elements) {
            if (randomWeight < element.weight) {
                return element.value;
            }
            randomWeight -= element.weight;
        }
        ;
    }
    ;
}
;

import { BlockTypes } from "@minecraft/server";
import * as MINECRAFT_UTILS_FUNCTIONS from "utilities/minecraft_utils_functions";
/**
 * Custom component pour les more_tnt.
 */
export class BlockMoreTntComponent {
    // Recopie le comportement d'une tnt intéragit avec un briquet, le block more_tnt est détruit et une entité more_tnt est spawn. Si le more_tnt est intéragit avec un bloc, le block est placé en fonction de la face intéragit.
    onPlayerInteract(arg) {
        const { block: moreTntBlock, player, face } = arg; // Récupère le block, le joueur et la face du block sur laquelle le joueur a intéragit.
        const playerInventoryComponent = player.getComponent("inventory"); // Récupère le composant inventory du joueur.
        const playerContainer = playerInventoryComponent.container; // Récupère le container du joueur.
        const itemStackHeldByPlayer = playerContainer.getItem(player.selectedSlotIndex); // Récupère l'itemStack tenu par le joueur.
        if (itemStackHeldByPlayer === undefined)
            return; // Si l'itemStack tenu par le joueur est undefined, on arrête la fonction.
        if (itemStackHeldByPlayer.typeId === "minecraft:flint_and_steel") { // Si l'itemStack tenu par le joueur est un briquet.
            const moreTntBlockTypeId = moreTntBlock.typeId; // Récupère le typeId du block more_tnt.
            moreTntBlock.setType("minecraft:air"); // Change le block more_tnt en air.
            MINECRAFT_UTILS_FUNCTIONS.updateItemDurability(player, itemStackHeldByPlayer, player.selectedSlotIndex, 1); // Décrémente la durabilité de l'itemStack tenu par le joueur.
            const locationToSpawnMoreTntEntity = { x: moreTntBlock.x + 0.5, y: moreTntBlock.y, z: moreTntBlock.z + 0.5 }; // L'emplacement où l'entité more_tnt sera spawn.
            moreTntBlock.dimension.spawnEntity(`${moreTntBlockTypeId}`, locationToSpawnMoreTntEntity); // Spawn l'entité more_tnt.
            return; // Arrête la fonction.
        }
        else {
            const itemStackBlockType = BlockTypes.get(itemStackHeldByPlayer.typeId); // Récupère le blockType de l'itemStack tenu par le joueur.
            if (itemStackBlockType === undefined)
                return; // Si le blockType de l'itemStack tenu par le joueur est undefined, on arrête la fonction.
            MINECRAFT_UTILS_FUNCTIONS.placeBlockDependingFaceInteracted(itemStackBlockType, moreTntBlock, face); // Place le block en fonction de la face du block intéragit.
            return; // Arrête la fonction.
        }
        ;
    }
    ;
    // Recopie le comportement d'une tnt, si le block more_tnt est alimenté par un signal de redstone, le block more_tnt est détruit et une entité more_tnt est spawn.
    onTick(arg) {
        const { block: moreTntBlock } = arg; // Récupère le block.
        if (MINECRAFT_UTILS_FUNCTIONS.isBlockAlimented(moreTntBlock) === false)
            return; // Si le block n'est pas alimenté par un signal de redstone, on arrête la fonction.
        const moreTntBlockTypeId = moreTntBlock.typeId; // Récupère le typeId du block more_tnt.
        moreTntBlock.setType("minecraft:air"); // Change le block more_tnt en air.
        const locationToSpawnMoreTntEntity = { x: moreTntBlock.x + 0.5, y: moreTntBlock.y, z: moreTntBlock.z + 0.5 }; // L'emplacement où l'entité more_tnt sera spawn.
        moreTntBlock.dimension.spawnEntity(`${moreTntBlockTypeId}`, locationToSpawnMoreTntEntity); // Spawn l'entité more_tnt.
        return; // Arrête la fonction.
    }
    ;
}
;

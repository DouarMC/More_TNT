import { system, world } from "@minecraft/server";
import * as ALL_DATAS from "utilities/datas";
// Remplace les blocks impactés par une explosion de TNT de diamant par des blocs de diamant.
world.beforeEvents.explosion.subscribe((eventData) => {
    const { source: diamondTntEntity } = eventData; // Récupère l'entité source de l'explosion.
    if (diamondTntEntity.typeId !== "douarmc:tnt_diamond")
        return; // Si l'entité source de l'explosion n'est pas une entité de type 'douarmc:tnt_diamond', on arrête la fonction.
    const impactedBlocks = eventData.getImpactedBlocks(); // Récupère les blocks impactés par l'explosion.
    const filteredImpactedBlocks = impactedBlocks.filter(block => ALL_DATAS.blockTypesToReplaceByMoreTnt.includes(block.typeId)); // Filtre les blocks impactés pour ne garder que les blocks de type 'minecraft:grass_block', 'minecraft:dirt', 'minecraft:stone' et 'minecraft:sand'.
    eventData.cancel = true; // Annule l'explosion.
    system.run(() => {
        for (const filteredImpactedBlock of filteredImpactedBlocks) { // Pour chaque block impacté.
            filteredImpactedBlock.setType("minecraft:diamond_block"); // Change le block en block de diamant.
        }
        ;
    });
});

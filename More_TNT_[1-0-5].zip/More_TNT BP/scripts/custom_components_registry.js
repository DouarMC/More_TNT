import { world } from "@minecraft/server";
import * as ALL_BLOCKS_CUSTOM_COMPONENTS from "blocks/custom_components/custom_components";
world.beforeEvents.worldInitialize.subscribe((eventData) => {
    eventData.blockComponentRegistry.registerCustomComponent("douarmc:more_tnt", new ALL_BLOCKS_CUSTOM_COMPONENTS.BlockMoreTntComponent());
});

import { world, system } from "@minecraft/server";
import * as FUNCTIONS_UTILITIES from "utilities/functions";
world.beforeEvents.itemUseOn.subscribe((eventData) => {
    const { block: tnt_custom, itemStack, source } = eventData;
    if (itemStack.typeId !== "minecraft:flint_and_steel")
        return;
    if (!tnt_custom.hasTag("douarmc:tnt_custom"))
        return;
    //-------
    eventData.cancel = true;
    const tntTypeId = tnt_custom.typeId;
    system.run(() => {
        tnt_custom.setType("minecraft:air");
        const sourceContainer = FUNCTIONS_UTILITIES.getPlayerContainer(source);
        FUNCTIONS_UTILITIES.decrementItemStackDurability(sourceContainer.getSlot(source.selectedSlot));
        const xLoc = tnt_custom.x + 0.5, yLoc = tnt_custom.y, zLoc = tnt_custom.z + 0.5;
        tnt_custom.dimension.spawnEntity(`${tntTypeId}`, { x: xLoc, y: yLoc, z: zLoc });
    });
});

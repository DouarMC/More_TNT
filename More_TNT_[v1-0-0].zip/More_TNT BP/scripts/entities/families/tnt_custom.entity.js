import { world } from "@minecraft/server";
import * as FUNCTIONS_UTILITIES from "utilities/functions";
world.afterEvents.entitySpawn.subscribe((eventData) => {
    const { entity: tntCustom } = eventData;
    if (!tntCustom.matches({ families: ["douarmc:tnt_custom"] }))
        return;
    //---------------
    FUNCTIONS_UTILITIES.doFlashingAnimation(tntCustom);
});

import { world } from "@minecraft/server";
world.afterEvents.explosion.subscribe((eventData) => {
    const { source } = eventData;
    if (source.typeId !== "douarmc:tnt_diamond")
        return;
    //------------
    const impactedBlocks = eventData.getImpactedBlocks();
    impactedBlocks.forEach((impactedBlock) => {
        impactedBlock.setType("minecraft:diamond_block");
    });
});

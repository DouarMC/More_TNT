import { system } from "@minecraft/server";
export function decrementItemStackDurability(containerSlot, damageNumber = 1) {
    const itemStack = containerSlot.getItem();
    const durabilityComponent = itemStack.getComponent("durability");
    try {
        durabilityComponent.damage += damageNumber;
        containerSlot.setItem(itemStack);
    }
    catch (e) {
        containerSlot.setItem();
    }
    ;
}
;
export function getPlayerContainer(player) {
    return player.getComponent("inventory").container;
}
;
export function doFlashingAnimation(entity) {
    let isFlashing = false;
    function toggleFlashing() {
        try {
            const nextFlashingState = isFlashing ? false : true;
            entity.setProperty("douarmc:is_flashing", nextFlashingState);
            isFlashing = !isFlashing;
        }
        catch (e) {
            return;
        }
        ;
    }
    ;
    const intervalId = system.runInterval(toggleFlashing, 5);
    const checkEntityExistence = system.runInterval(() => {
        if (!entity.isValid()) {
            system.clearRun(intervalId);
            system.clearRun(checkEntityExistence);
        }
        ;
    });
}
;
export function getBlocksFromList(blockList, blockToFind) {
    return blockList.filter((block) => block.hasTag(blockToFind));
}
;

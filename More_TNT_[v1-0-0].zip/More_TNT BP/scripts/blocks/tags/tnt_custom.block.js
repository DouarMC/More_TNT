import { system, world } from "@minecraft/server";
import * as FUNCTIONS_UTILITIES from "utilities/functions";
world.beforeEvents.explosion.subscribe((eventData) => {
    const { source } = eventData;
    if (!source.matches({ families: ["douarmc:tnt_custom"] }))
        return;
    //-----------
    const allImpactedBlocks = eventData.getImpactedBlocks();
    const allTntCustom = FUNCTIONS_UTILITIES.getBlocksFromList(allImpactedBlocks, "douarmc:tnt_custom");
    for (let tntCustom of allTntCustom) {
        const tntTypeId = tntCustom.typeId;
        system.run(() => {
            tntCustom.setType("minecraft:air");
            tntCustom.dimension.spawnEntity(`${tntTypeId}<douarmc:from_explosion>`, tntCustom.location);
        });
    }
    ;
});

import { BlockTypes } from "@minecraft/server";
import * as ALL_FUNCTIONS from "utilities/functions";
export class BlockMoreTntComponent {
    onPlayerInteract(arg) {
        const { block: moreTntBlock, player, face } = arg;
        const playerInventoryComponent = player.getComponent("inventory");
        const playerContainer = playerInventoryComponent.container;
        const itemStackHeldByPlayer = playerContainer.getItem(player.selectedSlotIndex);
        if (itemStackHeldByPlayer === undefined)
            return;
        if (itemStackHeldByPlayer.typeId === "minecraft:flint_and_steel") {
            const moreTntBlockTypeId = moreTntBlock.typeId;
            moreTntBlock.setType("minecraft:air");
            playerContainer.setItem(player.selectedSlotIndex, ALL_FUNCTIONS.decrementItemStackDurability(itemStackHeldByPlayer));
            const locationToSpawnMoreTntEntity = { x: moreTntBlock.x + 0.5, y: moreTntBlock.y, z: moreTntBlock.z + 0.5 };
            moreTntBlock.dimension.spawnEntity(`${moreTntBlockTypeId}`, locationToSpawnMoreTntEntity);
            return;
        }
        else {
            const itemStackBlockType = BlockTypes.get(itemStackHeldByPlayer.typeId);
            if (itemStackBlockType === undefined)
                return;
            ALL_FUNCTIONS.placeBlockDependingFaceInteracted(itemStackBlockType, moreTntBlock, face);
            return;
        }
        ;
    }
    ;
    onTick(arg) {
        const { block: moreTntBlock } = arg;
        if (ALL_FUNCTIONS.isBlockAlimented(moreTntBlock) === false)
            return;
        const moreTntBlockTypeId = moreTntBlock.typeId;
        moreTntBlock.setType("minecraft:air");
        const locationToSpawnMoreTntEntity = { x: moreTntBlock.x + 0.5, y: moreTntBlock.y, z: moreTntBlock.z + 0.5 };
        moreTntBlock.dimension.spawnEntity(`${moreTntBlockTypeId}`, locationToSpawnMoreTntEntity);
        return;
    }
    ;
}
;

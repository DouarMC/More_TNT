import { system, world } from "@minecraft/server";
// Fait exploser les More TNT quand elles sont impacté par une explosion.
world.beforeEvents.explosion.subscribe((eventData) => {
    const allImpactedBlocks = eventData.getImpactedBlocks();
    const moreTntsImpacted = allImpactedBlocks.filter((block) => block.hasTag("douarmc:more_tnt"));
    for (const moreTntBlock of moreTntsImpacted) {
        const moreTntBlockTypeId = moreTntBlock.typeId;
        system.run(() => {
            moreTntBlock.setType("minecraft:air");
            moreTntBlock.dimension.spawnEntity(`${moreTntBlockTypeId}<douarmc:from_explosion>`, moreTntBlock.location);
        });
    }
});

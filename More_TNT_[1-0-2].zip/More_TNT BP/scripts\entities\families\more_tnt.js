import { system, world } from "@minecraft/server";
// Permet aux TNT d'avoir l'animation de Flashing comme les TNT ou Creepers.
world.afterEvents.entitySpawn.subscribe((eventData) => {
    const { entity: moreTntEntity } = eventData;
    if (moreTntEntity.matches({ families: ["douarmc:more_tnt"] }) === false)
        return;
    let isFlashing = false;
    const toggleFlashing = system.runInterval(() => {
        try {
            const nextFlashingPropertyState = isFlashing ? false : true;
            moreTntEntity.setProperty("douarmc:is_flashing", nextFlashingPropertyState);
            isFlashing = !isFlashing;
        }
        catch (e) {
            if (moreTntEntity.isValid() === false)
                system.clearRun(toggleFlashing);
        }
        ;
    }, 5);
});

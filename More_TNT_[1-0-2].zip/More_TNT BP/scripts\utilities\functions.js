/**
 * Décrémenter la durabilité de l'itemStack spécifié ou renvoie Undefined
*/
export function decrementItemStackDurability(itemStack, damageAmount = 1) {
    const durabilityComponent = itemStack.getComponent("minecraft:durability");
    if (durabilityComponent.damage + damageAmount >= durabilityComponent.maxDurability) {
        return undefined;
    }
    else {
        durabilityComponent.damage += damageAmount;
        return itemStack;
    }
    ;
}
;
/**
 * Placer un bloc en fonction de la face du bloc intéragit
 */
export function placeBlockDependingFaceInteracted(blockToPlace, blockInteracted, blockFaceInteracted) {
    const dimmension = blockInteracted.dimension;
    let block = undefined;
    switch (blockFaceInteracted) {
        case "Down":
            block = blockInteracted.below();
            break;
        case "East":
            block = blockInteracted.east();
            break;
        case "North":
            block = blockInteracted.north();
            break;
        case "South":
            block = blockInteracted.south();
            break;
        case "Up":
            block = blockInteracted.above();
            break;
        case "West":
            block = blockInteracted.west();
            break;
    }
    ;
    const entitiesAtBlockLocation = dimmension.getEntities({ "location": block.location, "families": ["mob", "player"] });
    if (entitiesAtBlockLocation.length != 0)
        return;
    block.setType(blockToPlace);
}
;
/**
 * Teste si le bloc est alimenté par un signal de redstone
 */
export function isBlockAlimented(block) {
    const connectedBlocks = [block.above(), block.below(), block.east(), block.north(), block.south(), block.west()];
    for (const connectedBlock of connectedBlocks) {
        if (connectedBlock.getRedstonePower() !== undefined && connectedBlock.getRedstonePower() !== 0) {
            return true;
        }
        ;
    }
    ;
    return false;
}
;

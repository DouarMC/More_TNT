import { system, world } from "@minecraft/server";
// Comportement de la Tnt Diamant.
world.beforeEvents.explosion.subscribe((eventData) => {
    const { source: diamondTntEntity } = eventData;
    if (diamondTntEntity.typeId !== "douarmc:tnt_diamond")
        return;
    const impactedBlocks = eventData.getImpactedBlocks();
    eventData.cancel = true;
    system.run(() => {
        impactedBlocks.forEach((impactedBlock) => {
            impactedBlock.setType("minecraft:diamond_block");
        });
    });
});

import { world } from "@minecraft/server";
import { BlockMoreTntComponent } from "exports";
world.beforeEvents.worldInitialize.subscribe((eventData) => {
    eventData.blockTypeRegistry.registerCustomComponent("douarmc:more_tnt", new BlockMoreTntComponent());
});

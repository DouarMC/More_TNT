/**
 * Cette fonction prend une liste d'objets composé d'une valeur et d'un poids de chance, et envoie un element au hasard basé sur le poids de chance.
 * @param elements La liste d'objets composé d'une valeur et d'un poids de chance.
 * @returns
 */
export function chooseRandomElementWithWeight(elements) {
    const totalWeight = elements.reduce((total, item) => total + item.weight, 0); // Calcule le poids total.
    let randomWeight = Math.random() * totalWeight; // Génère un poids aléatoire.
    for (const element of elements) { // Pour chaque élément de la liste.
        if (randomWeight < element.weight) { // Si le poids aléatoire est inférieur au poids de l'élément.
            return element.value; // On retourne la valeur de l'élément.
        }
        randomWeight -= element.weight; // On retire le poids de l'élément au poids aléatoire.
    }
    ;
}
;
;

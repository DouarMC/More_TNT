import { EquipmentSlot } from "@minecraft/server";
/**
 * Met à jour la durabilité d'un item.
 * @param player Le joueur.
 * @param itemStack L'itemStack.
 * @param inventorySlot L'emplacement de l'inventaire.
 * @param damage Les dégâts infligés à l'item.
 */
export function updateItemDurability(player, itemStack, inventorySlot = EquipmentSlot.Mainhand, damage = 1) {
    const itemDurabilityComponent = itemStack.getComponent("minecraft:durability"); // Récupération du composant 'durability' de l'item.
    if (typeof inventorySlot === "number") {
        const playerInventoryComponent = player.getComponent("inventory"); // Récupération du composant 'inventory' du joueur.
        const playerContainer = playerInventoryComponent.container; // Récupération du container du joueur.
        if (itemDurabilityComponent.maxDurability <= itemDurabilityComponent.damage + damage) { // Si la durabilité de l'item est inférieure ou égale à 0, on enlève l'item.
            playerContainer.setItem(inventorySlot, undefined); // Enlève l'item.
        }
        else if (itemDurabilityComponent.damage + damage < 0) { // Si les dégâts infligés sont inférieurs à 0, on remet les dégâts à 0.
            itemDurabilityComponent.damage = 0; // Remet les dégâts à 0.
            playerContainer.setItem(inventorySlot, itemStack); // Met à jour l'item.
        }
        else { // Sinon, on ajoute les dégâts infligés à l'item.
            itemDurabilityComponent.damage += damage; // Ajoute les dégâts infligés à l'item.
            playerContainer.setItem(inventorySlot, itemStack); // Met à jour l'item.
        }
        ;
    }
    else {
        const playerEquippableComponent = player.getComponent("minecraft:equippable"); // Récupération du composant 'equippable' du joueur.
        if (itemDurabilityComponent.maxDurability <= itemDurabilityComponent.damage + damage) { // Si la durabilité de l'item est inférieure ou égale à 0, on enlève l'item.
            playerEquippableComponent.setEquipment(inventorySlot, undefined); // Enlève l'item.
        }
        else if (itemDurabilityComponent.damage + damage < 0) { // Si les dégâts infligés sont inférieurs à 0, on remet les dégâts à 0.
            itemDurabilityComponent.damage = 0; // Remet les dégâts à 0.
            playerEquippableComponent.setEquipment(inventorySlot, itemStack); // Met à jour l'item.
        }
        else { // Sinon, on ajoute les dégâts infligés à l'item.
            itemDurabilityComponent.damage += damage; // Ajoute les dégâts infligés à l'item.
            playerEquippableComponent.setEquipment(inventorySlot, itemStack); // Met à jour l'item.
        }
        ;
    }
    ;
}
;
/**
 * Placer un bloc en fonction de la face du bloc intéragit
 * @param blockToPlace Le block à placer
 * @param blockInteracted Le block intéragit
 * @param blockFaceInteracted La face du block intéragit
 * @returns
 */
export function placeBlockDependingFaceInteracted(blockToPlace, blockInteracted, blockFaceInteracted) {
    let blockToPlaceLocation = undefined; // L'emplacement du block à placer.
    switch (blockFaceInteracted) { // En fonction de la face du block intéragit, on définit l'emplacement du block à placer.
        case "Down":
            blockToPlaceLocation = blockInteracted.below().location;
            break; // Si la face est "Down", on place le block en dessous du block intéragit.
        case "East":
            blockToPlaceLocation = blockInteracted.east().location;
            break; // Si la face est "East", on place le block à l'est du block intéragit.
        case "North":
            blockToPlaceLocation = blockInteracted.north().location;
            break; // Si la face est "North", on place le block au nord du block intéragit.
        case "South":
            blockToPlaceLocation = blockInteracted.south().location;
            break; // Si la face est "South", on place le block au sud du block intéragit.
        case "Up":
            blockToPlaceLocation = blockInteracted.above().location;
            break; // Si la face est "Up", on place le block au dessus du block intéragit.
        case "West":
            blockToPlaceLocation = blockInteracted.west().location;
            break; // Si la face est "West", on place le block à l'ouest du block intéragit.
    }
    ;
    const entitiesAtBlockLocation = blockInteracted.dimension.getEntities({ location: blockToPlaceLocation, families: ["mob", "player"] }); // Récupération des entités à l'emplacement du block à placer.
    if (entitiesAtBlockLocation.length != 0)
        return; // Si il y a des entités à l'emplacement du block à placer, on arrête la fonction.
    blockInteracted.dimension.setBlockType(blockToPlaceLocation, blockToPlace); // On place le block à l'emplacement défini.
}
;
/**
 * Teste si le bloc est alimenté par un signal de redstone
 * @param block
 * @returns
 */
export function isBlockAlimented(block) {
    const connectedBlocks = [block.above(), block.below(), block.east(), block.north(), block.south(), block.west()]; // Les blocks connectés au block.
    for (const connectedBlock of connectedBlocks) { // Pour chaque block connecté au block.
        if (connectedBlock.getRedstonePower() !== undefined && connectedBlock.getRedstonePower() !== 0) { // Si le block connecté a un signal de redstone.
            return true; // On retourne true.
        }
        ;
    }
    ;
    return false; // On retourne false.
}
;
export class ALL_FUNCTIONS {
    /**
     * Prend une liste d'objets composé d'une valeur et d'un poids de chance, et envoie un element au hasard basé sur le poids de chance.
     * @param elements
     * @returns
     */
    static chooseRandomElementWithWeight(elements) {
        const totalWeight = elements.reduce((total, item) => total + item.weight, 0);
        let randomWeight = Math.random() * totalWeight;
        for (const element of elements) {
            if (randomWeight < element.weight) {
                return element.value;
            }
            randomWeight -= element.weight;
        }
        ;
    }
    ;
}
;

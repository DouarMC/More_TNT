/**
 * Les types de blocks à remplacer par des blocs de more_tnt.
 */
export const blockTypesToReplaceByMoreTnt = ["minecraft:grass_block", "minecraft:dirt", "minecraft:stone", "minecraft:sand"];
/**
 * Les types de blocks à remplacer par des blocs de more_tnt.
 */
export const replacementBlockTypesIceTnt = [
    { value: "minecraft:ice", weight: 5 }, // Le block de remplacement est de type 'minecraft:ice' avec un poids de chance de 5.
    { value: "minecraft:blue_ice", weight: 2 }, // Le block de remplacement est de type 'minecraft:blue_ice' avec un poids de chance de 2.
    { value: "minecraft:packed_ice", weight: 3 }, // Le block de remplacement est de type 'minecraft:packed_ice' avec un poids de chance de 3.
    { value: "minecraft:snow", weight: 4 }, // Le block de remplacement est de type 'minecraft:snow' avec un poids de chance de 4.
    { value: "minecraft:powder_snow", weight: 1 }, // Le block de remplacement est de type 'minecraft:powder_snow' avec un poids de chance de 1.
];

import { system, world } from "@minecraft/server";
// Fait exploser les More TNT quand elles sont impacté par une explosion.
world.beforeEvents.explosion.subscribe((eventData) => {
    const allImpactedBlocks = eventData.getImpactedBlocks(); // Récupère tous les blocks impactés par l'explosion.
    const moreTntsImpacted = allImpactedBlocks.filter((block) => block.hasTag("douarmc:more_tnt")); // Filtre les blocks impactés pour ne garder que les blocks de type more_tnt.
    for (const moreTntBlock of moreTntsImpacted) { // Pour chaque block more_tnt impacté.
        const moreTntBlockTypeId = moreTntBlock.typeId; // Récupère le typeId du block more_tnt.
        system.run(() => {
            moreTntBlock.setType("minecraft:air"); // Change le block more_tnt en air.
            moreTntBlock.dimension.spawnEntity(`${moreTntBlockTypeId}<douarmc:from_explosion>`, moreTntBlock.location); // Spawn l'entité more_tnt.
        });
    }
});

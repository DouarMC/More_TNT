import { world, system, TicksPerSecond, EntityDamageCause } from "@minecraft/server";
import * as ALL_DATAS from "utilities/datas";
import * as UTILS_FUNCTIONS from "utilities/utils_functions";
// Remplace les blocks impactés par une explosion de TNT de glace par des blocs de glace.
world.beforeEvents.explosion.subscribe((eventData) => {
    const { dimension, source: iceTntEntity } = eventData; // Récupère la dimension et l'entité source de l'explosion.
    const impactedBlocks = eventData.getImpactedBlocks(); // Récupère les blocks impactés par l'explosion.
    const filteredImpactedBlocks = impactedBlocks.filter(block => ALL_DATAS.blockTypesToReplaceByMoreTnt.includes(block.typeId)); // Filtre les blocks impactés pour ne garder que les blocks définis dans 'blockTypesToReplaceByMoreTnt'.
    if (iceTntEntity === undefined)
        return; // Si l'entité source de l'explosion est undefined, on arrête la fonction.
    if (iceTntEntity.typeId !== "douarmc:tnt_ice")
        return; // Si l'entité source de l'explosion n'est pas une entité de type 'douarmc:tnt_ice', on arrête la fonction.
    eventData.cancel = true; // Annule l'explosion.
    const iceTntEntityLocation = iceTntEntity.location; // Récupère la location de l'entité source de l'explosion.
    system.run(() => {
        dimension.spawnParticle("minecraft:huge_explosion_emitter", iceTntEntityLocation); // Spawn une particule d'explosion.
        const radiusExplosion = 4; // Le rayon de l'explosion.
        const entitiesInRadiusExplosion = dimension.getEntities({ location: iceTntEntityLocation, maxDistance: radiusExplosion }); // Récupère les entités dans le rayon de l'explosion.
        for (const entityInRadiusExplosion of entitiesInRadiusExplosion) { // Pour chaque entité dans le rayon de l'explosion.
            entityInRadiusExplosion.addEffect("slowness", 15 * TicksPerSecond, { amplifier: 5, showParticles: false }); // Applique un effet de lenteur à l'entité.
            entityInRadiusExplosion.applyDamage(5, { cause: EntityDamageCause.freezing }); // Applique des dégâts à l'entité.
        }
        ;
        if (filteredImpactedBlocks.length === 0)
            return; // Si il n'y a pas de blocks impactés, on arrête la fonction.
        for (const filteredImpactedBlock of filteredImpactedBlocks) { // Pour chaque block impacté.
            const replacementBlockType = UTILS_FUNCTIONS.chooseRandomElementWithWeight(ALL_DATAS.replacementBlockTypesIceTnt); // Récupère un block de remplacement aléatoire.
            filteredImpactedBlock.setType(replacementBlockType); // Change le block impacté par le block de remplacement.
        }
        ;
    });
});

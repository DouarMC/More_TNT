import { system, world } from "@minecraft/server";
// Permet aux TNT d'avoir l'animation de Flashing comme les TNT ou Creepers.
world.afterEvents.entitySpawn.subscribe((eventData) => {
    const { entity: moreTntEntity } = eventData; // Récupère l'entité.
    if (moreTntEntity.matches({ families: ["douarmc:more_tnt"] }) === false)
        return; // Si l'entité n'est pas de la famille 'douarmc:more_tnt', on arrête la fonction.
    moreTntEntity.applyKnockback(1, 1, 0.1, 0.25); // Applique un knockback à l'entité.
    let isFlashing = false; // Si l'entité est en train de flasher.
    const toggleFlashingIntervalID = system.runInterval(() => {
        try { // Essaie d'exécuter le code.
            const nextFlashingPropertyState = isFlashing ? false : true; // Définit l'état de la propriété 'douarmc:is_flashing'.
            moreTntEntity.setProperty("douarmc:is_flashing", nextFlashingPropertyState); // Change la propriété 'douarmc:is_flashing' de l'entité.
            isFlashing = !isFlashing; // Change l'état de 'isFlashing'.
        }
        catch (e) { // Si une erreur est détectée.
            if (moreTntEntity.isValid() === false)
                system.clearRun(toggleFlashingIntervalID); // Si l'entité n'est plus valide, on arrête l'intervalle.
        }
        ;
    }, 5);
});
